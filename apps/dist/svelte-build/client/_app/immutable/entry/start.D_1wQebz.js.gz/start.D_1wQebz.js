import{a as t}from"../chunks/D7IrhsA3.js";export{t as start};
